using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterTerrain : MonoBehaviour
{
    [SerializeField]
    private Rigidbody rb;
    
    [SerializeField]
    private float movementSpeed, coefficient;

    [SerializeField]
    private LayerMask WhatIsGround;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Movement();
    }

    void Update()
    {
        SurfaceAlignment();
        // Your other code...
    }

    void Movement()
    {
        float x = Input.GetAxisRaw("Horizontal");
        float y = Input.GetAxisRaw("Vertical");
        Vector3 movement = new Vector3(x, 0, y);
        Vector3 counterMovement = new Vector3(-rb.velocity.x, 0, -rb.velocity.z);

        rb.AddForce(movement * movementSpeed);
        rb.AddForce(counterMovement * coefficient);
    }

    void SurfaceAlignment()
    {
        Ray ray = new Ray(transform.position, -transform.up);
        RaycastHit info = new RaycastHit();
        if (Physics.Raycast(ray, out info, WhatIsGround))
        {
            transform.rotation = Quaternion.FromToRotation(Vector3.up, info.normal);
        }
    }
}
