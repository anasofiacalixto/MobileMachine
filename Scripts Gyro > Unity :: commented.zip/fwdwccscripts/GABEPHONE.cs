using UnityEngine;
using System.Collections;
public class GABEPHONE : MonoBehaviour


//UNITY script that connects Gabriels phone using ZigSim to a unity camera
{
    public OSC osc;

    // Use this for initialization
    void Start()
    {
        osc.SetAddressHandler("/ZIGSIM/G7tvcb_UO8ADp9Pk/quaternion", OnReceiveXYZ);
    }

    // Update is called once per frame
    void Update()
    {
        // You can add any additional update logic here if needed
    }

    void OnReceiveXYZ(OscMessage message)
    {
        float x = message.GetFloat(0);
        float y = message.GetFloat(1);
        float z = message.GetFloat(2);
        float w = message.GetFloat(3);

        Debug.Log("Received Quaternion: " + x + ", " + y + ", " + z + ", " + w);

        // Create the new rotation from the received values
        Quaternion targetRotation = new Quaternion(-x, -z, -y, w);

        // Use slerp to smoothly interpolate between the current rotation and the new rotation
        float slerpFactor = 0.05f;  // Adjust this value to control the speed of interpolation
        transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, slerpFactor);
    }
}