using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GyroController : MonoBehaviour
{
    private bool gyroEnabled; // Indicates if the gyroscope is enabled
    private Gyroscope gyro; // Reference to the Gyroscope component

    private GameObject cameraContainer; // Container for the camera rotation
    private Quaternion rot; // Initial rotation adjustment

    // Start is called before the first frame update
    void Start()
    {
        // Create a container for camera rotation
        cameraContainer = new GameObject("Camera Container");
        // Set its position to match the current object's position
        cameraContainer.transform.position = transform.position;
        // Make the current object a child of the camera container to inherit its rotation
        transform.SetParent(cameraContainer.transform);

        // Enable the gyroscope and store whether it was successful
        gyroEnabled = EnableGyro();
    }

    // Method to enable the gyroscope
    private bool EnableGyro()
    {
        // Check if the device supports gyroscope
        if (SystemInfo.supportsGyroscope)
        {
            
            gyro = Input.gyro;
            
            gyro.enabled = true;

            
            cameraContainer.transform.rotation = Quaternion.Euler(90f, 90f, 0f);
            
            rot = new Quaternion(0, 0, 1, 0);

            
            return true;
        }

        // Return false if the device doesn't support gyroscope
        return false;
    }

    // Update is called once per frame
    void Update()
    {
        // Check if the gyroscope is enabled
        if (gyroEnabled)
        {
            // Update object rotation based on gyroscope data, adjusting for different coordinate systems
            transform.localRotation = gyro.attitude * rot;
        }
    }
}
