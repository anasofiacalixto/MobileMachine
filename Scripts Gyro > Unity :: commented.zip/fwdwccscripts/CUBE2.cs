using UnityEngine;
using System.Collections;

public class CUBE2 : MonoBehaviour
{
    
    public OSC osc;

    // Use this for initialization
    void Start()
    {
        // Set up a handler for incoming OSC messages with a specific address
        osc.SetAddressHandler("/ZIGSIM/rSa0GTVSS4liecwD/quaternion", OnReceiveXYZ);
    }

    // Update is called once per frame
    void Update()
    {
        // Nothing is done in the Update method for this script
        // The rotation of the cube is updated in the OnReceiveXYZ method
    }

    // This method is called when an OSC message with the specified address is received
    void OnReceiveXYZ(OscMessage message)
    {
        // Extract the quaternion components from the OSC message
        float x = message.GetFloat(0);
        float y = message.GetFloat(1);
        float z = message.GetFloat(2);
        float w = message.GetFloat(3);

        // Log the received quaternion components
        Debug.Log("Received Quaternion: " + x + ", " + y + ", " + z + ", " + w);

        // Create a new quaternion from the received values
        Quaternion targetRotation = new Quaternion(-x, -z, -y, w);

        // Use (slerp) to smoothly interpolate between the current rotation and the new rotation
        float slerpFactor = 0.05f;  // Adjust this value to control the speed of interpolation
        transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, slerpFactor);
    }
}
